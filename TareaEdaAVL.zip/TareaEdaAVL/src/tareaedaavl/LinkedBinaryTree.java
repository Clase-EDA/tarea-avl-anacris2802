package tareaedaavl;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Queue;
import java.util.Stack;


public abstract class LinkedBinaryTree<T> implements BinaryTreeADT<T>{
    NodoBin<T> raiz;
    int cont;
    
    public boolean isEmpty(){
        return cont!=0;
    }
    
    public int size(){
        return cont;
    }
    
    
    public Iterator<T> inOrder(){
        ArrayList<T> lista=new ArrayList();
        inOrder(raiz, lista);
        return lista.iterator();
    }
    
    private void inOrder(NodoBin<T> actual, ArrayList<T> lis){
        if(actual==null){
            return;
        }
        inOrder(actual.getIzq(),lis);
        lis.add(actual.getElem());
        inOrder(actual.getDer(),lis);
        return;
    }
    
    public Iterator<T> preOrder(){
        ArrayList<T> lista=new ArrayList();
        preOrder(raiz, lista);
        return lista.iterator();
    }
    
    private void preOrder(NodoBin<T> actual, ArrayList<T> lis){
        if(actual==null){
            return;
        }
        lis.add(actual.getElem());
        preOrder(actual.getIzq(),lis);
        preOrder(actual.getDer(),lis);
        return;
    }
    
    public Iterator<T> preOrderIterativo(){
        Stack<NodoBin<T>> s= new Stack();
        ArrayList<T> lista=new ArrayList();
        s.push(raiz);
        while(!s.isEmpty()){
            NodoBin<T> e=s.pop();
            lista.add(e.getElem());
            if(e.getDer()!=null)
                s.push(e.getDer());
            if(e.getIzq()!=null)
                s.push(e.getIzq());
        }
        return lista.iterator();
    }
    
    public Iterator<T> postOrder(){
        ArrayList<T> lista=new ArrayList();
        postOrder(raiz, lista);
        return lista.iterator();
    }
    
    private void postOrder(NodoBin<T> actual, ArrayList<T> lis){
        if(actual==null){
            return;
        }
        postOrder(actual.getIzq(),lis);
        postOrder(actual.getDer(),lis);
        lis.add(actual.getElem());
        return;
    }
    
    public Iterator<T> levelOrder(){
        Queue<NodoBin<T>> s=null; 
        ArrayList<T> lista=new ArrayList();
        s.add(raiz);
        while(!s.isEmpty()){
            NodoBin<T> e=s.remove();
            lista.add(e.getElem());
            if(e.getDer()!=null)
                s.add(e.getDer());
            if(e.getIzq()!=null)
                s.add(e.getIzq());
        }
        return lista.iterator();
    }
    
}
