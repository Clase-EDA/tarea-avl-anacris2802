package tareaedaavl;


import static java.lang.Double.max;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hca
 */
public abstract class LinkedBinarySearchTree<T> extends LinkedBinaryTree<T> implements BinarySearchTreeADT<T> {
    public T encuentraMin(){
        NodoBin<T> actual=raiz;
        while(actual.getIzq()!=null)
            actual=actual.getIzq();
        return actual.getElem();
    }
    public T encuentraMax(){
        NodoBin<T> actual=raiz;
        while(actual.getDer()!=null)
            actual=actual.getDer();
        return actual.getElem();
    }
    public void inserta(T elem){
        NodoBin<T> nuevo=new NodoBin<T>(elem);
        NodoBin<T> actual=raiz;
        if(actual.getDer()!=null || actual.getIzq()!=null)
            if(actual.compareTo(elem)<0){
                inserta((T) actual.getIzq());
            }
            else{
                inserta((T) actual.getDer());
            }
        actual.cuelga(nuevo);
        cont++;
        }
    
    
    public NodoBin<T> insertaRecursivo(NodoBin<T> actual, T elem){
        if(actual==null)
            return new NodoBin(elem);
        if(actual.compareTo(elem)>0)
            actual.cuelga(insertaRecursivo(actual.getIzq(),elem));
        else
            actual.cuelga(insertaRecursivo(actual.getDer(),elem));
        return actual;
    }
    
    /*
    Para eliminar:
    1.- Eliminar una hoja: 
            Que u papá apunte al nulo
    2.- Eliminar nodo con un solo hijo:
            - Que mi papá apunte a mi hijo en lugar de a mi
    3.- Eliminar nodo con 2 hijos:
            -Sustituir el valor del nodo por el valor de su uscesor inOrder
            -Eliminar el nodo en donde estaba el sucesor inOrder
    -------> Sucesor: hoja más izquierda del sub-arbol derecho
    
    */
    
    private NodoBin<T> busca(T elem){
        NodoBin<T> actual=raiz;
        while(actual!=null && elem!=actual.getElem()){
            if(actual.compareTo(elem)>0)
                    actual=actual.getIzq();
        else
                actual=actual.getDer();
        }
        return actual;
    }
    
    public void elimina(T elem){
        NodoBin<T> actual=busca(elem);
        
        if(actual==null)
            return;
        if(cont==1){
            raiz=null;
            cont=0;
            return;
        }
        if(actual.getIzq()==null && actual.getIzq()==null){
            if(actual.getPapá().getIzq()==actual)
                    actual.getPapá().setIzq(null);
            else
                actual.getPapá().setDer(null);
            cont--;
            return;
        }
        if(actual.getIzq()==null || actual.getDer()==null){
            if(actual.getDer()==null){
                actual.papá.cuelga(actual.getIzq());
                cont--;
            }
            else{
                actual.papá.cuelga(actual.getDer());
                cont--;
            }
            return;
        }
        
        NodoBin<T> actual2=actual;
        actual2=actual2.getDer();
        while(actual2.getIzq()!=null){
            actual2=actual2.getIzq();
        }
        if(actual2.getDer()!=null){
            actual2.getPapá().cuelga(actual2.getDer());
        }
        else
            actual2.getPapá().setIzq(null);
        
        actual.setElem(actual2.getElem());
        cont--;
        return;
    }
}
    
    
    
    