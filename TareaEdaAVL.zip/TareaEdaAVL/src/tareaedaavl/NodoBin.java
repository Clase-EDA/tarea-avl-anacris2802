package tareaedaavl;


import static java.lang.Double.max;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hca
 */
public class NodoBin< T > { 

T elem; 

NodoBin< T > izq, der, papá; 
double fe;

NodoBin( T e ) { 

elem = e; 

izq=null; 

der=null; 
fe=altura(der)-altura(izq);
} 

    public double getFe() {
        return fe;
    }

    public void setFe(double fe) {
        this.fe = fe;
    }

public int numDescendiente( ){  //Cuenta cuántos descendientes tiene este nodo 
    int res=0;
    if(izq==null){
        if(der==null)
            return res;
        res++;
        der.numDescendiente();
    }
    if(der==null){
        if(izq==null)
            return res;
        res++;
        izq.numDescendiente();
    }
    return res;
}



public int numHijosDirectos(){
    int cont=0;
    if(izq!=null)
        cont++;
    if(der!=null)
        cont++;
    return cont;
}

    public T getElem() {
        return elem;
    }

    public NodoBin<T> getIzq() {
        return izq;
    }

    public NodoBin<T> getDer() {
        return der;
    }

    public void setElem(T elem) {
        this.elem = elem;
    }

    public void setIzq(NodoBin<T> izq) {
        this.izq = izq;
    }

    public void setDer(NodoBin<T> der) {
        this.der = der;
    }

    public NodoBin<T> getPapá() {
        return papá;
    }

    public void setPapá(NodoBin<T> papá) {
        this.papá = papá;
    }
    public int compareTo(T e){
        if(elem==e)
            return 0;
        if(elem.hashCode()>e.hashCode())
            return -1;
        else
            return 1;
    }

    public void cuelga(NodoBin<T> n){
        if(n==null){
            return;
        }
        if(elem==null){
            der=n;
            n.setPapá(this);
            return;
        }
        if(n.getElem()==null){
            der=n;
        }
 // if(n.getElem().compareTo(elem)<0)
        if(n.compareTo(elem)<0){
            izq=n;
        }
        else
            der=n;
        n.setPapá(this);
        
    }
    
    
    
    public double altura(){
        int res=0, cont1=0, cont2=0;
        NodoBin<T> actual=this;
        return altura(this);
    }
    public double altura(NodoBin<T> actual){
            if(actual==null)
                return 0;
           double izq=altura(actual.getIzq())+1;
           double der=altura(actual.getDer())+1;
           return max(izq,der);
        }
}