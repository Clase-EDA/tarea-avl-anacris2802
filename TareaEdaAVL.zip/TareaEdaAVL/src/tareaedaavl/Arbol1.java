package tareaedaavl;


import static java.lang.Double.max;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Queue;


public abstract class Arbol1<T> extends LinkedBinarySearchTree<T>{
        NodoBin<T> raiz;
        int n;
        Arbol1(){
            raiz=new NodoBin(null);
            cont=0;
            n=0;
        }
        
        //Dado una rbol binario haga un método para calcular su altura. 
    //La altura de un árbol es la longitud del camino más largo de la raíz a alguna hoja
        public double altura(){
        int res=0, cont1=0, cont2=0;
        NodoBin<T> actual=raiz;
        return altura(raiz);
    }
        public double altura(NodoBin<T> actual){
            if(actual==null)
                return 0;
           double izq=altura(actual.getIzq())+1;
           double der=altura(actual.getDer())+1;
           return max(izq,der);
        }
        
        
        
       
        
        
        public void InsertaAVL(T elem){
            //Inserta nodo nuevo
            NodoBin<T> nuevo=new NodoBin(elem);
            NodoBin<T> actual=raiz.getDer(),papá=actual;
            if(cont==0){
                raiz.setDer(nuevo);
                nuevo.setPapá(raiz);
                cont++;
                return;
            }
            while(actual!=null){
                papá=actual;
                if(actual.compareTo(elem)>0)
                    actual=actual.getIzq();
                else
                    actual=actual.getDer();
            }
            papá.cuelga(nuevo);
            cont++;
            
            //Viajar hacia la raíz actualizando los factores de equilibrio
            //      Si vengo de la izquierda -1
            //      Si vengo de la derecha +1
            //Termina cuando:
            //      Se convierte en 2 o -2, ROTAR
            //      Se convierte en 0
            //      Se llega a la raiz
            actual=nuevo;
            while(actual.papá!=raiz){
                if(actual.papá.getDer()==actual)
                    actual.papá.setFe(actual.papá.getFe()+1);
                else
                    actual.papá.setFe(actual.papá.getFe()-1);
                if(actual.papá.getFe()==0)
                    return;
                if(actual.papá.getFe()>1 || actual.papá.getFe()<-1){
                    rotar(actual.papá);
                    return;
                }
                actual=actual.papá;
            }
            return;
        }
        
        public void eliminaAVL(T elem){
            //hoja
            //un hijo
            //dos hijos
            elimina(elem);
            checaAVL(0,raiz);
            
        }
            
        private void checaAVL(int c, NodoBin<T> actual){
            if(c>=cont){
                return;
            }
            if(actual.getFe()>Math.abs(1)){
                rotar(actual);
            }
            
            while(c<cont ){
                if(actual.getDer()!=null)
                    checaAVL(c+1,actual.getDer());
                else
                    if(actual.getIzq()!=null)
                        checaAVL(c+1,actual.getIzq());
                    else
                        checaAVL(c+1,actual.getPapá());
                    
            }
            return;
        }
        
        public NodoBin<T> rotar(NodoBin<T> actual){
            //determinar caso
            NodoBin<T> alfa=actual;
            if(alfa.getFe()==-2 && alfa.getIzq().getFe()==1){
                RotaIzqDer(alfa);
            }
            if(alfa.getFe()==-2 && alfa.getIzq().getFe()==-1){
                RotaIzqIzq(alfa);
            }
            if(alfa.getFe()==2 && alfa.getDer().getFe()==1){
                RotaDerDer(alfa);
            }
            if(alfa.getFe()==2 && alfa.getDer().getFe()==-1){
                RotaDerIzq(alfa);
            }
            return actual;
               
    }
        private NodoBin<T> RotaDerDer(NodoBin<T> n){
        NodoBin<T> p=n.getPapá();
        
        NodoBin<T> alfa=n;
        NodoBin<T> beta=n.getDer();
        NodoBin<T> gamma=n.getDer().getDer();
        
        NodoBin<T> a=alfa.getIzq();
        NodoBin<T> b=beta.getIzq();
        
        alfa.setDer(b);
        if(b!=null)
            b.setPapá(alfa);
        beta.cuelga(alfa);
        
        alfa.setFe(1+max(altura(a),altura(b)));
        beta.setFe(1+max(altura(alfa),altura(gamma)));
        
        if(p!=null)
            p.cuelga(beta);
        else{
            raiz=beta;
            beta.setPapá(null);
        }
        
        return p;
    }
    
    private NodoBin<T> RotaIzqIzq(NodoBin<T> n){
        NodoBin<T> p=n.getPapá();
        
        NodoBin<T> alfa=n;
        NodoBin<T> beta=n.getIzq();
        NodoBin<T> gamma=n.getIzq().getIzq();
        
        NodoBin<T> a=alfa.getDer();
        NodoBin<T> b=beta.getDer();
        
        alfa.setIzq(b);
        if(b!=null)
            b.setPapá(b);
        beta.cuelga(alfa);
        
        alfa.setFe(1+max(altura(a),altura(b)));
        beta.setFe(1+max(altura(alfa),altura(gamma)));
        
        if(p!=null)
            p.cuelga(beta);
        else{
            raiz=beta;
            beta.setPapá(null);
        }
        return p;
    }
    
    private NodoBin<T> RotaIzqDer(NodoBin<T> n){
        NodoBin<T> p=n.getPapá();
        
        NodoBin<T> alfa=n;
        NodoBin<T> beta=n.getIzq();
        NodoBin<T> gamma=n.getIzq().getDer();
        
       
        
        NodoBin<T> a=alfa.getDer();
        NodoBin<T> b=beta.getIzq();
        NodoBin<T> c=gamma.getIzq();
        NodoBin<T> d=gamma.getDer();
        
        gamma.cuelga(alfa);
        gamma.cuelga(beta);
        beta.setDer(c);
        if(c!=null)
            c.setPapá(beta);
        alfa.setIzq(d);
        if(d!=null)
            d.setPapá(alfa);
        
        beta.setFe(1+max(altura(b),altura(c)));
        alfa.setFe(1+max(altura(d),altura(a)));
        gamma.setFe(1+max(altura(beta),altura(alfa)));
        
        if(p!=null)
            p.cuelga(gamma);
        else{
            raiz=gamma;
            gamma.setPapá(null);
        }
        return p;
    }
    
    private NodoBin<T> RotaDerIzq(NodoBin<T> n){
        NodoBin<T> p=n.getPapá();
        
        NodoBin<T> alfa=n;
        NodoBin<T> beta=n.getDer();
        NodoBin<T> gamma=n.getDer().getIzq();
        
       
        
        NodoBin<T> a=alfa.getIzq();
        NodoBin<T> b=beta.getDer();
        NodoBin<T> c=gamma.getDer();
        NodoBin<T> d=gamma.getIzq();
        
        gamma.cuelga(alfa);
        gamma.cuelga(beta);
        beta.setIzq(c);
        if(c!=null)
            c.setPapá(beta);
        alfa.setDer(d);
        if(d!=null)
            d.setPapá(alfa);
        
        beta.setFe(1+max(altura(b),altura(c)));
        alfa.setFe(1+max(altura(d),altura(a)));
        gamma.setFe(1+max(altura(beta),altura(alfa)));
        
        if(p!=null)
            p.cuelga(gamma);
        else{
            raiz=gamma;
            gamma.setPapá(null);
        }
        return p;
    }
        
        public NodoBin<T> buscaAVL(T elem){
        NodoBin<T> actual=raiz;
        while(actual!=null && elem!=actual.getElem()){
            if(actual.compareTo(elem)>0)
                    actual=actual.getIzq();
        else
                actual=actual.getDer();
        }
        return actual;
    }
        
        //Imprime por nivel
        public void imprimePorNivel(){
          Queue<NodoBin<T>> s=null; 
          ArrayList<T> lista=new ArrayList();
          s.add(raiz);
        while(!s.isEmpty()){
            NodoBin<T> e=s.remove();
            System.out.println("ELEMENTO: "+ e.getElem()+" FACTOR DE EQUILIBRIO: "+ e.getFe());
            if(e.getDer()!=null)
                s.add(e.getDer());
            if(e.getIzq()!=null)
                s.add(e.getIzq());
            }
        }
        
        
    
        
    
    }